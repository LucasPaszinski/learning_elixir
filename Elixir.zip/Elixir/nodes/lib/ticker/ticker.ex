defmodule Ticker do
  # 2 segundos
  @interval 2000
  # global name
  @name :ticker

  def start do
    pid = spawn(__MODULE__, :generator2, [[]])
    :global.register_name(@name, pid)
  end

  def register(client_pid) do
    send(:global.whereis_name(@name), {:register, client_pid})
  end

  def generator(clients) do
    receive do
      {:register, pid} ->
        IO.puts("Registering #{inspect(pid)}")
        generator([pid | clients])
    after
      @interval ->
        IO.puts("tick #{Time.utc_now()}")

        Enum.each(clients, fn client ->
          send(client, {:tick})
        end)

        generator(clients)
    end
  end

  def generator2(clients) do
    IO.puts(inspect(clients))

    receive do
      {:register, pid} ->
        IO.puts("Registering #{inspect(pid)}")

        case clients do
          [] ->
            send_tick([pid])

          [head | []] when is_pid(head) ->
            send_tick([head | pid])

          [[] | tail] ->
            send_tick([tail | pid])

          [head | tail] ->
            send_tick([clients | pid])
        end
    after
      @interval ->
        IO.puts("tick #{Time.utc_now()}")
        send_tick(clients)
    end
  end

  defp send_tick([head | tail]) when is_pid(head) do
    send(head, {:tick, head})
    generator2([tail | head])
  end

  defp send_tick([head | tail]) do
    generator2([tail | head])
  end

  defp send_tick([head | tail]) do
    generator2([tail | head])
  end

  defp send_tick(clients) do
    generator2(clients)
  end
end

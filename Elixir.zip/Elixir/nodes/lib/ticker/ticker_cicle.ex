defmodule Ticker do
  # global name
  @name :ticker

  def start do
    pid = spawn(__MODULE__, :cicler, [[]])
    :global.register_name(@name, pid)
  end

  def register(client_pid) do
    send(:global.whereis_name(@name), {:register, client_pid})
  end

  def get_register(pid) do
    send(:global.whereis_name(@name), {:next, pid})
  end

  def cicler(clients) do
    IO.puts("clients #{inspect(clients)}")

    case clients do
      [[] | tail] ->
        IO.puts("removed empty head, letting tail #{inspect(tail)}")
        cicler(tail)

      [head | tail] when is_pid(head) ->
        receive do
          {:next, to} ->
              IO.puts("#{inspect(to)} asked from who to call. It should call #{inspect(head)}")
              send(to, {:send_to, head})
              cicler([tail | head])
          {:register, new} ->
            IO.puts("Register new pid #{inspect new}")
            cicler([clients | new])
        end

      pid when is_pid(pid) ->
        receive do
          {:next, to} ->
            IO.puts("#{inspect(to)} asked from who to call. But there is onl one on the list so will call it's self #{inspect(pid)}")
            send(to, {:send_to, pid})
            cicler(pid)

          {:register, new} ->
            IO.puts("Register new pid #{inspect new}")
            cicler([clients | new])
        end

      [] ->
        receive do
          {:register, new} ->
            IO.puts("Register new pid #{inspect new}")
            get_register(new)
            cicler(new)
        end
    end
  end
end

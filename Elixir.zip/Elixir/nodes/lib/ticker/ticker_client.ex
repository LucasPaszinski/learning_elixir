defmodule Ticker.Client do
  # require Ticker
  def start do
    pid = spawn(__MODULE__, :receiver, [])
    Ticker.register(pid)
  end

  def receiver do
    receive do
      {:tick, pid} ->
        IO.puts("tock on client #{inspect(pid)} #{Time.utc_now()}")
        receiver()
    end
  end
end

defmodule Ticker.Cli do
  # require Ticker
  def start do
    pid = spawn(__MODULE__, :receiver, [])
    Ticker.register(pid)
    pid
  end

  def receiver do
    receive do
      {:tick} ->
        IO.puts("tock on client #{inspect(self())}")

        receiver_pid = self()

        spawn(fn ->
          :timer.sleep(2000)
          Ticker.get_register(receiver_pid)
        end)

        receiver()

      {:send_to, to} ->
        IO.puts("I'm sending to #{inspect(to)} the tick")
        send(to, {:tick})
        receiver()
    end
  end
end

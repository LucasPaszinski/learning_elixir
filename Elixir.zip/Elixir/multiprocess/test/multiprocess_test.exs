defmodule MultiprocessTest do
  use ExUnit.Case
  doctest Multiprocess

  test "greets the world" do
    assert Multiprocess.hello() == :world
  end
end

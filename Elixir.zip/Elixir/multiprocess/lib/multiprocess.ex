defmodule Multiprocess do
  @moduledoc """
  Documentation for `Multiprocess`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> Multiprocess.hello()
      :world

  """
  def hello do
    :world
  end
end

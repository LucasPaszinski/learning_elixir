defmodule SLink do
  def die_exit do
    receive do
      {sender, value} ->
        send(sender, {:ok, "I receive your message: \n\t#{inspect(value)}"})
        exit(:you_died)
    end
  end

  def die_raise do
    receive do
      {sender, value} ->
        send(sender, {:ok, "I receive your message: \n\t#{inspect(value)}"})
        raise "Died"
    end
  end

  def run_link do
    Process.flag(:trap_exit, true)

    IO.puts "\nLink | Exit"


    pid = spawn_link(SLink, :die_exit, [])
    send(pid, {self(), "Yo bro!"})

    :timer.sleep(500)

    receive do
      msg -> IO.inspect(msg)
    end

    receive do
      msg -> IO.inspect(msg)
    end

    IO.puts "\nLink | Raise"

    pid = spawn_link(SLink, :die_raise, [])
    send(pid, {self(), "Yo bro!"})

    :timer.sleep(500)

    receive do
      msg -> IO.inspect(msg)
    end

    receive do
      msg -> IO.inspect(msg)
    end
  end

  def run_monitor do
    Process.flag(:trap_exit, true)

    IO.puts "\nMonitor | Exit"

    {pid, _ref} = spawn_monitor(SLink, :die_exit, [])
    send(pid, {self(), "Yo bro!"})

    :timer.sleep(500)

    receive do
      msg -> IO.inspect(msg)
    end

    receive do
      msg -> IO.inspect(msg)
    end

    IO.puts "\nMonitor | Raise"

    {pid, _ref} = spawn_monitor(SLink, :die_raise, [])
    send(pid, {self(), "Yo bro!"})

    :timer.sleep(500)

    receive do
      msg -> IO.inspect(msg)
    end

    receive do
      msg -> IO.inspect(msg)
    end
  end
end

SLink.run_link()

SLink.run_monitor()

defmodule SimpleProcess do
  def greet do
    IO.puts "Hello I'm #{to_string(SimpleProcess)}"
  end
end

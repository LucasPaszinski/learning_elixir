defmodule Fred do
  def get_msg do
    Enum.map(1..1000000,&(&1*2))
    receive do
      {sender, msg} ->
        send sender, {self(), "I'm Fred"}
    end

    get_msg()
  end
end

defmodule Betty do
  def get_msg do
    receive do
      {sender, msg} ->
        send sender, {self(), "I'm Betty"}
    end

    get_msg()
  end
end

pid1 = spawn(Fred, :get_msg, [])
pid2 = spawn(Betty, :get_msg, [])

send pid1, {self(),"Who are you!?"}
send pid2, {self(),"Who are you!?"}

receive do
  {_,msg} -> IO.puts msg
end

receive do
  {_,msg2} -> IO.puts msg2
end

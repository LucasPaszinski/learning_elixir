# defmodule Link1 do
#   import :timer, only: [sleep: 1]

#   def sad_func do
#     sleep(500)
#     exit(:boom)
#   end

#   def run do
#     spawn(Link1, :sad_func, [])

#     receive do
#       msg ->
#         IO.puts("MESSAGE RECEIVED: #{inspect(msg)}")
#     after
#       1000 ->
#         IO.puts("Nothing  happened as far as I am concerned")
#     end
#   end
# end

# Link1.run()

defmodule Link2 do
  import :timer, only: [sleep: 1]

  def sad_function do
    sleep(500)
    exit(:boom)
  end

  def run do
    # Process.flag(:trap_exit, true)
    res = spawn_link(Link2, :sad_function, [])

    receive do
      msg ->
        IO.puts("MESSAGE RECEIVED: #{inspect(msg)}")
    after
      1000 ->
        IO.puts("Nothing happened as far as I am concerned")
    end
  end
end

Link2.run()

defmodule Monitor1 do
  import :timer, only: [sleep: 1]

  def sad_function do
    sleep(500)
    exit(:boom)
  end

  def run do
    # Process.flag(:trap_exit, true)
    res = spawn_monitor(Monitor1, :sad_function, [])
    IO.puts inspect res

    receive do
      msg ->
        IO.puts("MESSAGE RECEIVED: #{inspect(msg)}")
    after
      1000 ->
        IO.puts("Nothing happened as far as I am concerned")
    end
  end
end

Monitor1.run()

defmodule Chain do
  def counter(acc, next_pid) do
    receive do
      n ->
#         IO.puts(
#           "\nI'm counter number #{acc} and received #{n}.
# I'm passing #{n + 1} to #{inspect(next_pid)}\n"
#         )

        send(next_pid, n + 1)
    end
  end

  def create_process(n) do
    code_to_run = fn acc, send_to ->
      spawn(Chain, :counter, [acc, send_to])
    end

    last = Enum.reduce(1..n, self(), code_to_run)

    send(last, 0)

    receive do
      final_answer when is_integer(final_answer) ->
        "Result is #{inspect(final_answer)}"
    end
  end

  def run(n) do
    :timer.tc(Chain, :create_process, [n])
    |> IO.inspect()
  end
end
